package com.test.beans;

public class Address {
    private String city = "Chennai";
    public Address() {
        System.out.println("My city:" + city);
    }

    public Address(String city) {
    }

    public void setCity(String city)
    {
        this.city=city;

    }
    public String getCity() {
        return city;
    }
}
